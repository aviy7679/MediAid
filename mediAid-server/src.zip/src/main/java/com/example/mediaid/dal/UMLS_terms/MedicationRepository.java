package com.example.mediaid.dal.UMLS_terms;

import org.springframework.stereotype.Repository;

@Repository
public interface MedicationRepository extends BaseUmlsRepository<Medication> {
}
