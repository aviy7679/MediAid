package com.example.mediaid.dal.UMLS_terms;

import org.springframework.stereotype.Repository;

@Repository
public interface SymptomRepository extends BaseUmlsRepository<Symptom> {
}
